const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  genre: { type: String, required: true },
  platform: { type: String, required: true },
  publisher: { type: String },
}, { timestamps: true });

module.exports = mongoose.model('Game', gameSchema);
