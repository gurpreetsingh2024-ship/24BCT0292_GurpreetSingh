const express = require('express');
const router = express.Router();
const { getOverview, getGamesBreakdown } = require('../controllers/statsController');

router.get('/overview', getOverview);
router.get('/games-breakdown', getGamesBreakdown);

module.exports = router;
