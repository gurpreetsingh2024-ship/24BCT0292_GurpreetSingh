const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema({
  tournament: { type: mongoose.Schema.Types.ObjectId, ref: 'Tournament', required: true },
  team1: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  team2: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
  stage: { type: String },
  score: { type: String },
  playedAt: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('Match', matchSchema);
