const Team = require('../models/Team');
const Player = require('../models/Player');

// GET /api/leaderboard/teams?limit=10
exports.getTopTeams = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const teams = await Team.find()
      .populate('game', 'name genre platform')
      .sort({ wins: -1 })
      .limit(limit);

    const ranked = teams.map((team, index) => ({
      rank: index + 1,
      teamName: team.teamName,
      region: team.region,
      game: team.game,
      wins: team.wins,
      foundedYear: team.foundedYear,
    }));

    res.status(200).json({
      title: 'Top Teams Leaderboard',
      count: ranked.length,
      leaderboard: ranked,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/leaderboard/players?limit=10
exports.getTopEarners = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const players = await Player.find()
      .populate('team', 'teamName region')
      .sort({ earnings: -1 })
      .limit(limit);

    const ranked = players.map((player, index) => ({
      rank: index + 1,
      gamertag: player.gamertag,
      realName: player.realName,
      role: player.role,
      country: player.country,
      team: player.team,
      earnings: `$${player.earnings.toLocaleString()}`,
    }));

    res.status(200).json({
      title: 'Top Players by Earnings',
      count: ranked.length,
      leaderboard: ranked,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/leaderboard/team-of-the-season
exports.getTeamOfTheSeason = async (req, res) => {
  try {
    const team = await Team.findOne()
      .populate('game', 'name genre platform publisher')
      .sort({ wins: -1 });

    if (!team) {
      return res.status(404).json({ message: 'No teams found' });
    }

    const roster = await Player.find({ team: team._id })
      .select('gamertag realName role country earnings');

    res.status(200).json({
      title: 'Team of the Season',
      award: '🏆 #1 Ranked by Total Wins',
      team: {
        id: team._id,
        teamName: team.teamName,
        region: team.region,
        game: team.game,
        wins: team.wins,
        foundedYear: team.foundedYear,
      },
      roster,
      rosterSize: roster.length,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
