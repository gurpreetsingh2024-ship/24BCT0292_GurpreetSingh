const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const gameRoutes = require('./src/routes/gameRoutes');
const teamRoutes = require('./src/routes/teamRoutes');
const playerRoutes = require('./src/routes/playerRoutes');
const tournamentRoutes = require('./src/routes/tournamentRoutes');
const matchRoutes = require('./src/routes/matchRoutes');
const leaderboardRoutes = require('./src/routes/leaderboardRoutes');
const statsRoutes = require('./src/routes/statsRoutes');
const errorHandler = require('./src/middlewares/errorHandler');

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/', (req, res) => {
  res.status(200).json({
    message: 'GameVault API is running',
    version: '2.0.0',
    endpoints: {
      games: '/api/games',
      teams: '/api/teams',
      players: '/api/players',
      tournaments: '/api/tournaments',
      matches: '/api/matches',
      leaderboard: '/api/leaderboard',
      stats: '/api/stats',
    },
  });
});

app.use('/api/games', gameRoutes);
app.use('/api/teams', teamRoutes);
app.use('/api/players', playerRoutes);
app.use('/api/tournaments', tournamentRoutes);
app.use('/api/matches', matchRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/stats', statsRoutes);

app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

app.use(errorHandler);

module.exports = app;
