# GameVault — Esports Tournament & Team Management System

Backend-only REST API for managing esports games, teams, players, tournaments, and matches. Built with Node.js, Express.js, and MongoDB (Mongoose).

## Tech Stack

- Node.js v20.x
- Express.js v4.18.x
- MongoDB v7.x
- Mongoose v8.x

## Setup Instructions

1. Clone the repository
   ```
   git clone https://github.com/gurpreetsingh2024-ship/24BCT0292_GurpreetSingh.git
   cd gamevault
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Create a `.env` file in the project root (see example below)

4. Start MongoDB locally, or use a MongoDB Atlas connection string

5. Run the server
   ```
   npm run dev
   ```
   or
   ```
   npm start
   ```

6. Server runs at `http://localhost:5000`

## .env Example

```
PORT=5000
MONGO_URI=mongodb://localhost:27017/gamevault
```

## API Reference

Base URL: `http://localhost:5000/api`

### Games

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | /api/games | Add a new game |
| GET | /api/games | List all games |
| GET | /api/games/:id | Get a game by ID |
| PUT | /api/games/:id | Update a game |
| DELETE | /api/games/:id | Delete a game |

### Teams

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | /api/teams | Register a new team |
| GET | /api/teams | List teams (filter by game/region) |
| GET | /api/teams/:id | Get a team with game info |
| PUT | /api/teams/:id | Update team name, region, or wins |
| DELETE | /api/teams/:id | Delete a team |

### Players

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | /api/players | Register a new player |
| GET | /api/players | List players (filter by team/country/role) |
| GET | /api/players/:id | Get a player with team info |
| PUT | /api/players/:id | Update gamertag, role, team, or earnings |
| DELETE | /api/players/:id | Delete a player |

### Tournaments

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | /api/tournaments | Create a tournament |
| GET | /api/tournaments | List tournaments (filter by status/game) |
| GET | /api/tournaments/:id | Get a tournament with participants |
| PUT | /api/tournaments/:id | Update prize pool, format, dates, or status |
| DELETE | /api/tournaments/:id | Delete a tournament |
| POST | /api/tournaments/:id/register | Register a team into a tournament |

### Matches

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | /api/matches | Log a new match result |
| GET | /api/matches | List matches (filter by tournament/stage) |
| GET | /api/matches/:id | Get a match with team and tournament info |
| PUT | /api/matches/:id | Update score or declare a winner |
| DELETE | /api/matches/:id | Delete a match record |

## Project Structure

```
gamevault/
├── src/
│   ├── config/
│   │   └── db.js
│   ├── models/
│   │   ├── Game.js
│   │   ├── Team.js
│   │   ├── Player.js
│   │   ├── Tournament.js
│   │   └── Match.js
│   ├── controllers/
│   │   ├── gameController.js
│   │   ├── teamController.js
│   │   ├── playerController.js
│   │   ├── tournamentController.js
│   │   └── matchController.js
│   ├── routes/
│   │   ├── gameRoutes.js
│   │   ├── teamRoutes.js
│   │   ├── playerRoutes.js
│   │   ├── tournamentRoutes.js
│   │   └── matchRoutes.js
│   └── middlewares/
│       └── errorHandler.js
├── screenshots/
├── .env
├── .gitignore
├── app.js
├── server.js
├── package.json
└── README.md
```

## Author

Gurpreet Singh — 24BCT0292
