const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
  gamertag: { type: String, required: true, unique: true },
  realName: { type: String, required: true },
  role: { type: String, enum: ['IGL', 'Rifler', 'AWPer', 'Support', 'Entry'] },
  country: { type: String },
  team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
  earnings: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Player', playerSchema);
