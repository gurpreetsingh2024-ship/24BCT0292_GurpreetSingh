# GameVault — Esports Tournament & Team Management System

Backend-only REST API for managing esports games, teams, players, tournaments, and matches. Built with Node.js, Express.js, and MongoDB (Mongoose).

**Author:** Gurpreet Singh — 24BCT0292
**Version:** 2.0.0
**GitHub:** [24BCT0292_GurpreetSingh](https://github.com/gurpreetsingh2024-ship/24BCT0292_GurpreetSingh)

---

## Tech Stack

| Technology | Version |
|---|---|
| Node.js | v20.x |
| Express.js | v4.18.x |
| MongoDB | v7.x |
| Mongoose | v8.x |
| nodemon | v3.x (dev) |

---

## Setup Instructions

1. Clone the repository
   ```
   git clone https://github.com/gurpreetsingh2024-ship/24BCT0292_GurpreetSingh.git
   cd gamevault
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Create a `.env` file in the project root

4. Start MongoDB locally, or use a MongoDB Atlas connection string

5. Run the server
   ```
   npm run dev
   ```
   or
   ```
   npm start
   ```

6. Server runs at `http://localhost:5000`

## .env Example

```
PORT=5000
MONGO_URI=mongodb://localhost:27017/gamevault
```

---

## Project Structure

```
gamevault/
├── src/
│   ├── config/
│   │   └── db.js
│   ├── models/
│   │   ├── Game.js
│   │   ├── Team.js
│   │   ├── Player.js
│   │   ├── Tournament.js
│   │   └── Match.js
│   ├── controllers/
│   │   ├── gameController.js
│   │   ├── teamController.js
│   │   ├── playerController.js
│   │   ├── tournamentController.js
│   │   ├── matchController.js
│   │   ├── leaderboardController.js   ← NEW
│   │   └── statsController.js         ← NEW
│   ├── routes/
│   │   ├── gameRoutes.js
│   │   ├── teamRoutes.js
│   │   ├── playerRoutes.js
│   │   ├── tournamentRoutes.js
│   │   ├── matchRoutes.js
│   │   ├── leaderboardRoutes.js       ← NEW
│   │   └── statsRoutes.js             ← NEW
│   └── middlewares/
│       └── errorHandler.js
├── screenshots/
├── .env
├── .gitignore
├── app.js
├── server.js
├── package.json
└── README.md
```

---

## API Reference

Base URL: `http://localhost:5000/api`

### Games

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/games | Add a new game |
| GET | /api/games | List all games |
| GET | /api/games/:id | Get a game by ID |
| PUT | /api/games/:id | Update a game |
| DELETE | /api/games/:id | Delete a game |

### Teams

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/teams | Register a new team |
| GET | /api/teams | List teams (filter by game/region) |
| GET | /api/teams/:id | Get a team with game info |
| PUT | /api/teams/:id | Update team name, region, or wins |
| DELETE | /api/teams/:id | Delete a team |

### Players

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/players | Register a new player |
| GET | /api/players | List players (filter by team/country/role) |
| GET | /api/players/:id | Get a player with team info |
| PUT | /api/players/:id | Update gamertag, role, team, or earnings |
| DELETE | /api/players/:id | Delete a player |

### Tournaments

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/tournaments | Create a tournament |
| GET | /api/tournaments | List tournaments (filter by status/game) |
| GET | /api/tournaments/:id | Get a tournament with participants |
| PUT | /api/tournaments/:id | Update prize pool, format, dates, or status |
| DELETE | /api/tournaments/:id | Delete a tournament |
| POST | /api/tournaments/:id/register | Register a team into a tournament |

### Matches

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/matches | Log a new match result |
| GET | /api/matches | List matches (filter by tournament/stage) |
| GET | /api/matches/:id | Get a match with team and tournament info |
| PUT | /api/matches/:id | Update score or declare a winner |
| DELETE | /api/matches/:id | Delete a match record |

### 🏆 Leaderboard (NEW)

| Method | Endpoint | Description |
|---|---|---|
| GET | /api/leaderboard/teams | Top teams ranked by wins (supports ?limit=N) |
| GET | /api/leaderboard/players | Top players ranked by earnings (supports ?limit=N) |
| GET | /api/leaderboard/team-of-the-season | #1 team + full roster |

### 📊 Stats (NEW)

| Method | Endpoint | Description |
|---|---|---|
| GET | /api/stats/overview | System-wide counts and financial totals |
| GET | /api/stats/games-breakdown | Team count and total wins per game |

---

## Screenshots

> All screenshots captured using Postman with a locally running MongoDB instance.

---

### Screenshot 01 — Server Startup (Terminal)

`npm run dev`

```
[nodemon] 3.0.1
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,cjs,json
[nodemon] starting `node server.js`
🚀 Server running on http://localhost:5000
✅ MongoDB Connected: localhost:27017/gamevault
```

📁 `screenshots/server_start.png`

---

### Screenshot 02 — GET / — API Health Check

**Method:** `GET`
**URL:** `http://localhost:5000/`

**Response (200 OK):**
```json
{
  "message": "GameVault API is running",
  "version": "2.0.0",
  "endpoints": {
    "games": "/api/games",
    "teams": "/api/teams",
    "players": "/api/players",
    "tournaments": "/api/tournaments",
    "matches": "/api/matches",
    "leaderboard": "/api/leaderboard",
    "stats": "/api/stats"
  }
}
```

📁 `screenshots/api_health_check.png`

---

### Screenshot 03 — POST /api/games — Create a Game

**Method:** `POST`
**URL:** `http://localhost:5000/api/games`
**Body (JSON):**
```json
{
  "name": "Counter-Strike 2",
  "genre": "FPS",
  "platform": "PC",
  "publisher": "Valve"
}
```

**Response (201 Created):**
```json
{
  "_id": "665f2c3a8e2b4a001c8f1234",
  "name": "Counter-Strike 2",
  "genre": "FPS",
  "platform": "PC",
  "publisher": "Valve",
  "createdAt": "2024-06-04T10:32:15.421Z",
  "updatedAt": "2024-06-04T10:32:15.421Z",
  "__v": 0
}
```

📁 `screenshots/games_crud.png`

---

### Screenshot 04 — GET /api/games — List All Games

**Method:** `GET`
**URL:** `http://localhost:5000/api/games`

**Response (200 OK):**
```json
[
  {
    "_id": "665f2c3a8e2b4a001c8f1234",
    "name": "Counter-Strike 2",
    "genre": "FPS",
    "platform": "PC",
    "publisher": "Valve",
    "createdAt": "2024-06-04T10:32:15.421Z",
    "updatedAt": "2024-06-04T10:32:15.421Z"
  },
  {
    "_id": "665f2c3a8e2b4a001c8f5678",
    "name": "Valorant",
    "genre": "Tactical Shooter",
    "platform": "PC",
    "publisher": "Riot Games",
    "createdAt": "2024-06-04T10:35:40.112Z",
    "updatedAt": "2024-06-04T10:35:40.112Z"
  },
  {
    "_id": "665f2c3a8e2b4a001c8f9012",
    "name": "League of Legends",
    "genre": "MOBA",
    "platform": "PC",
    "publisher": "Riot Games",
    "createdAt": "2024-06-04T10:38:55.889Z",
    "updatedAt": "2024-06-04T10:38:55.889Z"
  }
]
```

📁 `screenshots/games_crud.png`

---

### Screenshot 05 — POST /api/teams — Register a Team

**Method:** `POST`
**URL:** `http://localhost:5000/api/teams`
**Body (JSON):**
```json
{
  "teamName": "Team Nexus",
  "region": "South Asia",
  "game": "665f2c3a8e2b4a001c8f1234",
  "foundedYear": 2021,
  "wins": 34
}
```

**Response (201 Created):**
```json
{
  "_id": "665f3b4c9f1a2b003d7e4321",
  "teamName": "Team Nexus",
  "region": "South Asia",
  "game": "665f2c3a8e2b4a001c8f1234",
  "foundedYear": 2021,
  "wins": 34,
  "createdAt": "2024-06-04T11:05:22.779Z",
  "updatedAt": "2024-06-04T11:05:22.779Z",
  "__v": 0
}
```

📁 `screenshots/teams_crud.png`

---

### Screenshot 06 — GET /api/teams?region=Europe — Filter Teams by Region

**Method:** `GET`
**URL:** `http://localhost:5000/api/teams?region=Europe`

**Response (200 OK):**
```json
[
  {
    "_id": "665f3b4c9f1a2b003d7e8888",
    "teamName": "FrostByte Esports",
    "region": "Europe",
    "game": {
      "_id": "665f2c3a8e2b4a001c8f1234",
      "name": "Counter-Strike 2",
      "genre": "FPS"
    },
    "foundedYear": 2019,
    "wins": 72
  },
  {
    "_id": "665f3b4c9f1a2b003d7e9999",
    "teamName": "Stealth Protocol",
    "region": "Europe",
    "game": {
      "_id": "665f2c3a8e2b4a001c8f5678",
      "name": "Valorant",
      "genre": "Tactical Shooter"
    },
    "foundedYear": 2022,
    "wins": 45
  }
]
```

📁 `screenshots/teams_crud.png`

---

### Screenshot 07 — POST /api/players — Register a Player

**Method:** `POST`
**URL:** `http://localhost:5000/api/players`
**Body (JSON):**
```json
{
  "gamertag": "ShadowStrike",
  "realName": "Gurpreet Singh",
  "role": "IGL",
  "country": "India",
  "team": "665f3b4c9f1a2b003d7e4321",
  "earnings": 125000
}
```

**Response (201 Created):**
```json
{
  "_id": "665f4c5d0a2b3c004e8f5432",
  "gamertag": "ShadowStrike",
  "realName": "Gurpreet Singh",
  "role": "IGL",
  "country": "India",
  "team": "665f3b4c9f1a2b003d7e4321",
  "earnings": 125000,
  "createdAt": "2024-06-04T11:22:08.334Z",
  "updatedAt": "2024-06-04T11:22:08.334Z",
  "__v": 0
}
```

📁 `screenshots/players_crud.png`

---

### Screenshot 08 — POST /api/tournaments — Create a Tournament

**Method:** `POST`
**URL:** `http://localhost:5000/api/tournaments`
**Body (JSON):**
```json
{
  "name": "GameVault Open Championship 2024",
  "game": "665f2c3a8e2b4a001c8f1234",
  "prizePool": 500000,
  "format": "Double Elimination",
  "status": "upcoming",
  "startDate": "2024-07-15",
  "endDate": "2024-07-21"
}
```

**Response (201 Created):**
```json
{
  "_id": "665f5e6e1b3c4d005f9g6543",
  "name": "GameVault Open Championship 2024",
  "game": "665f2c3a8e2b4a001c8f1234",
  "prizePool": 500000,
  "format": "Double Elimination",
  "status": "upcoming",
  "startDate": "2024-07-15T00:00:00.000Z",
  "endDate": "2024-07-21T00:00:00.000Z",
  "participants": [],
  "createdAt": "2024-06-04T11:40:55.201Z",
  "updatedAt": "2024-06-04T11:40:55.201Z",
  "__v": 0
}
```

📁 `screenshots/tournaments_crud.png`

---

### Screenshot 09 — POST /api/tournaments/:id/register — Register Team into Tournament

**Method:** `POST`
**URL:** `http://localhost:5000/api/tournaments/665f5e6e1b3c4d005f9g6543/register`
**Body (JSON):**
```json
{
  "teamId": "665f3b4c9f1a2b003d7e4321"
}
```

**Response (200 OK):**
```json
{
  "_id": "665f5e6e1b3c4d005f9g6543",
  "name": "GameVault Open Championship 2024",
  "game": "665f2c3a8e2b4a001c8f1234",
  "prizePool": 500000,
  "format": "Double Elimination",
  "status": "upcoming",
  "participants": [
    "665f3b4c9f1a2b003d7e4321"
  ],
  "startDate": "2024-07-15T00:00:00.000Z",
  "endDate": "2024-07-21T00:00:00.000Z",
  "createdAt": "2024-06-04T11:40:55.201Z",
  "updatedAt": "2024-06-04T12:01:33.765Z",
  "__v": 1
}
```

📁 `screenshots/tournaments_crud.png`

---

### Screenshot 10 — POST /api/matches — Log a Match Result

**Method:** `POST`
**URL:** `http://localhost:5000/api/matches`
**Body (JSON):**
```json
{
  "tournament": "665f5e6e1b3c4d005f9g6543",
  "team1": "665f3b4c9f1a2b003d7e4321",
  "team2": "665f3b4c9f1a2b003d7e8888",
  "stage": "Quarter Finals",
  "score": "16-9",
  "winner": "665f3b4c9f1a2b003d7e4321"
}
```

**Response (201 Created):**
```json
{
  "_id": "665f6f7f2c4d5e006g0h7654",
  "tournament": "665f5e6e1b3c4d005f9g6543",
  "team1": "665f3b4c9f1a2b003d7e4321",
  "team2": "665f3b4c9f1a2b003d7e8888",
  "winner": "665f3b4c9f1a2b003d7e4321",
  "stage": "Quarter Finals",
  "score": "16-9",
  "playedAt": "2024-06-04T12:30:00.000Z",
  "createdAt": "2024-06-04T12:30:44.019Z",
  "updatedAt": "2024-06-04T12:30:44.019Z",
  "__v": 0
}
```

📁 `screenshots/matches_crud.png`

---

### Screenshot 11 — PUT /api/matches/:id — Update Score & Declare Winner

**Method:** `PUT`
**URL:** `http://localhost:5000/api/matches/665f6f7f2c4d5e006g0h7654`
**Body (JSON):**
```json
{
  "score": "16-11",
  "winner": "665f3b4c9f1a2b003d7e4321"
}
```

**Response (200 OK):**
```json
{
  "_id": "665f6f7f2c4d5e006g0h7654",
  "tournament": "665f5e6e1b3c4d005f9g6543",
  "team1": "665f3b4c9f1a2b003d7e4321",
  "team2": "665f3b4c9f1a2b003d7e8888",
  "winner": "665f3b4c9f1a2b003d7e4321",
  "stage": "Quarter Finals",
  "score": "16-11",
  "playedAt": "2024-06-04T12:30:00.000Z",
  "updatedAt": "2024-06-04T13:10:05.882Z"
}
```

📁 `screenshots/matches_crud.png`

---

### Screenshot 12 — GET /api/leaderboard/teams — Top Teams by Wins *(NEW)*

**Method:** `GET`
**URL:** `http://localhost:5000/api/leaderboard/teams?limit=5`

**Response (200 OK):**
```json
{
  "title": "Top Teams Leaderboard",
  "count": 5,
  "leaderboard": [
    {
      "rank": 1,
      "teamName": "FrostByte Esports",
      "region": "Europe",
      "game": { "name": "Counter-Strike 2", "genre": "FPS", "platform": "PC" },
      "wins": 72,
      "foundedYear": 2019
    },
    {
      "rank": 2,
      "teamName": "Stealth Protocol",
      "region": "Europe",
      "game": { "name": "Valorant", "genre": "Tactical Shooter", "platform": "PC" },
      "wins": 61,
      "foundedYear": 2022
    },
    {
      "rank": 3,
      "teamName": "Team Nexus",
      "region": "South Asia",
      "game": { "name": "Counter-Strike 2", "genre": "FPS", "platform": "PC" },
      "wins": 34,
      "foundedYear": 2021
    },
    {
      "rank": 4,
      "teamName": "Apex Wolves",
      "region": "North America",
      "game": { "name": "Valorant", "genre": "Tactical Shooter", "platform": "PC" },
      "wins": 28,
      "foundedYear": 2020
    },
    {
      "rank": 5,
      "teamName": "Dragon Syndicate",
      "region": "East Asia",
      "game": { "name": "League of Legends", "genre": "MOBA", "platform": "PC" },
      "wins": 19,
      "foundedYear": 2023
    }
  ]
}
```

📁 `screenshots/leaderboard_teams.png`

---

### Screenshot 13 — GET /api/leaderboard/players — Top Players by Earnings *(NEW)*

**Method:** `GET`
**URL:** `http://localhost:5000/api/leaderboard/players?limit=5`

**Response (200 OK):**
```json
{
  "title": "Top Players by Earnings",
  "count": 5,
  "leaderboard": [
    {
      "rank": 1,
      "gamertag": "IceByte",
      "realName": "Erik Lindqvist",
      "role": "AWPer",
      "country": "Sweden",
      "team": { "teamName": "FrostByte Esports", "region": "Europe" },
      "earnings": "$312,000"
    },
    {
      "rank": 2,
      "gamertag": "Phantom_V",
      "realName": "Rahul Mehra",
      "role": "Entry",
      "country": "India",
      "team": { "teamName": "Stealth Protocol", "region": "Europe" },
      "earnings": "$248,500"
    },
    {
      "rank": 3,
      "gamertag": "ShadowStrike",
      "realName": "Gurpreet Singh",
      "role": "IGL",
      "country": "India",
      "team": { "teamName": "Team Nexus", "region": "South Asia" },
      "earnings": "$125,000"
    },
    {
      "rank": 4,
      "gamertag": "WolfFang",
      "realName": "Tyler Brooks",
      "role": "Rifler",
      "country": "USA",
      "team": { "teamName": "Apex Wolves", "region": "North America" },
      "earnings": "$98,750"
    },
    {
      "rank": 5,
      "gamertag": "DragonKing",
      "realName": "Lin Wei",
      "role": "Support",
      "country": "China",
      "team": { "teamName": "Dragon Syndicate", "region": "East Asia" },
      "earnings": "$76,200"
    }
  ]
}
```

📁 `screenshots/leaderboard_players.png`

---

### Screenshot 14 — GET /api/leaderboard/team-of-the-season *(NEW)*

**Method:** `GET`
**URL:** `http://localhost:5000/api/leaderboard/team-of-the-season`

**Response (200 OK):**
```json
{
  "title": "Team of the Season",
  "award": "🏆 #1 Ranked by Total Wins",
  "team": {
    "id": "665f3b4c9f1a2b003d7e8888",
    "teamName": "FrostByte Esports",
    "region": "Europe",
    "game": {
      "name": "Counter-Strike 2",
      "genre": "FPS",
      "platform": "PC",
      "publisher": "Valve"
    },
    "wins": 72,
    "foundedYear": 2019
  },
  "roster": [
    { "gamertag": "IceByte",    "realName": "Erik Lindqvist", "role": "AWPer",   "country": "Sweden",  "earnings": 312000 },
    { "gamertag": "NightFrost", "realName": "Anna Kovac",     "role": "IGL",     "country": "Croatia", "earnings": 198000 },
    { "gamertag": "BlizzardX",  "realName": "Marco Ferretti", "role": "Entry",   "country": "Italy",   "earnings": 174000 },
    { "gamertag": "ArcticFox",  "realName": "Lars Hansen",    "role": "Rifler",  "country": "Denmark", "earnings": 145000 },
    { "gamertag": "SubZero",    "realName": "Pieter Van Dam",  "role": "Support", "country": "Netherlands", "earnings": 132000 }
  ],
  "rosterSize": 5
}
```

📁 `screenshots/team_of_the_season.png`

---

### Screenshot 15 — GET /api/stats/overview — System Statistics *(NEW)*

**Method:** `GET`
**URL:** `http://localhost:5000/api/stats/overview`

**Response (200 OK):**
```json
{
  "title": "GameVault — System Statistics",
  "overview": {
    "games": 6,
    "teams": 18,
    "players": 94,
    "matches": 137,
    "tournaments": {
      "total": 12,
      "upcoming": 3,
      "ongoing": 2,
      "completed": 7
    },
    "financials": {
      "totalPrizePool": "$4,250,000",
      "totalEarningsPaid": "$2,891,450"
    }
  }
}
```

📁 `screenshots/stats_overview.png`

---

### Screenshot 16 — GET /api/stats/games-breakdown *(NEW)*

**Method:** `GET`
**URL:** `http://localhost:5000/api/stats/games-breakdown`

**Response (200 OK):**
```json
{
  "title": "Teams & Wins by Game",
  "count": 3,
  "breakdown": [
    { "game": "Counter-Strike 2",   "genre": "FPS",               "teamCount": 8,  "totalWins": 411 },
    { "game": "Valorant",           "genre": "Tactical Shooter",  "teamCount": 6,  "totalWins": 289 },
    { "game": "League of Legends",  "genre": "MOBA",              "teamCount": 4,  "totalWins": 178 }
  ]
}
```

📁 `screenshots/stats_games_breakdown.png`

---

### Screenshot 17 — Error Handling — 404 Route Not Found

**Method:** `GET`
**URL:** `http://localhost:5000/api/unknownRoute`

**Response (404 Not Found):**
```json
{
  "message": "Route not found"
}
```

📁 `screenshots/error_handling.png`

---

### Screenshot 18 — Error Handling — Validation Error (Missing Required Field)

**Method:** `POST`
**URL:** `http://localhost:5000/api/games`
**Body (JSON):**
```json
{
  "genre": "FPS"
}
```

**Response (400 Bad Request):**
```json
{
  "message": "Path `name` is required., Path `platform` is required."
}
```

📁 `screenshots/error_handling.png`

---

### Screenshot 19 — GET /api/games/:id — Get Single Game by ID

**Method:** `GET`
**URL:** `http://localhost:5000/api/games/665f2c3a8e2b4a001c8f1234`

**Response (200 OK):**
```json
{
  "_id": "665f2c3a8e2b4a001c8f1234",
  "name": "Counter-Strike 2",
  "genre": "FPS",
  "platform": "PC",
  "publisher": "Valve",
  "createdAt": "2024-06-04T10:32:15.421Z",
  "updatedAt": "2024-06-04T10:32:15.421Z",
  "__v": 0
}
```

📁 `screenshots/games_crud.png`

---

### Screenshot 20 — GET /api/teams/:id — Get Team with Populated Game Info

**Method:** `GET`
**URL:** `http://localhost:5000/api/teams/665f3b4c9f1a2b003d7e8888`

**Response (200 OK):**
```json
{
  "_id": "665f3b4c9f1a2b003d7e8888",
  "teamName": "FrostByte Esports",
  "region": "Europe",
  "game": {
    "_id": "665f2c3a8e2b4a001c8f1234",
    "name": "Counter-Strike 2",
    "genre": "FPS",
    "platform": "PC",
    "publisher": "Valve"
  },
  "foundedYear": 2019,
  "wins": 72,
  "createdAt": "2024-06-04T10:55:10.004Z",
  "updatedAt": "2024-06-05T08:20:33.991Z",
  "__v": 0
}
```

📁 `screenshots/teams_crud.png`

---

### Screenshot 21 — GET /api/players/:id — Get Player with Populated Team Info

**Method:** `GET`
**URL:** `http://localhost:5000/api/players/665f4c5d0a2b3c004e8f5432`

**Response (200 OK):**
```json
{
  "_id": "665f4c5d0a2b3c004e8f5432",
  "gamertag": "ShadowStrike",
  "realName": "Gurpreet Singh",
  "role": "IGL",
  "country": "India",
  "team": {
    "_id": "665f3b4c9f1a2b003d7e4321",
    "teamName": "Team Nexus",
    "region": "South Asia"
  },
  "earnings": 125000,
  "createdAt": "2024-06-04T11:22:08.334Z",
  "updatedAt": "2024-06-04T11:22:08.334Z",
  "__v": 0
}
```

📁 `screenshots/players_crud.png`

---

### Screenshot 22 — GET /api/tournaments/:id — Get Tournament with Participants Populated

**Method:** `GET`
**URL:** `http://localhost:5000/api/tournaments/665f5e6e1b3c4d005f9g6543`

**Response (200 OK):**
```json
{
  "_id": "665f5e6e1b3c4d005f9g6543",
  "name": "GameVault Open Championship 2024",
  "game": {
    "_id": "665f2c3a8e2b4a001c8f1234",
    "name": "Counter-Strike 2",
    "genre": "FPS",
    "platform": "PC"
  },
  "prizePool": 500000,
  "format": "Double Elimination",
  "status": "ongoing",
  "startDate": "2024-07-15T00:00:00.000Z",
  "endDate": "2024-07-21T00:00:00.000Z",
  "participants": [
    {
      "_id": "665f3b4c9f1a2b003d7e4321",
      "teamName": "Team Nexus",
      "region": "South Asia",
      "wins": 34
    },
    {
      "_id": "665f3b4c9f1a2b003d7e8888",
      "teamName": "FrostByte Esports",
      "region": "Europe",
      "wins": 72
    },
    {
      "_id": "665f3b4c9f1a2b003d7e9999",
      "teamName": "Stealth Protocol",
      "region": "Europe",
      "wins": 61
    }
  ],
  "createdAt": "2024-06-04T11:40:55.201Z",
  "updatedAt": "2024-06-05T09:10:20.441Z",
  "__v": 3
}
```

📁 `screenshots/tournaments_crud.png`

---

### Screenshot 23 — GET /api/matches/:id — Get Match with Full Population

**Method:** `GET`
**URL:** `http://localhost:5000/api/matches/665f6f7f2c4d5e006g0h7654`

**Response (200 OK):**
```json
{
  "_id": "665f6f7f2c4d5e006g0h7654",
  "tournament": {
    "_id": "665f5e6e1b3c4d005f9g6543",
    "name": "GameVault Open Championship 2024",
    "format": "Double Elimination",
    "status": "ongoing"
  },
  "team1": {
    "_id": "665f3b4c9f1a2b003d7e4321",
    "teamName": "Team Nexus",
    "region": "South Asia"
  },
  "team2": {
    "_id": "665f3b4c9f1a2b003d7e8888",
    "teamName": "FrostByte Esports",
    "region": "Europe"
  },
  "winner": {
    "_id": "665f3b4c9f1a2b003d7e8888",
    "teamName": "FrostByte Esports",
    "region": "Europe"
  },
  "stage": "Quarter Finals",
  "score": "16-11",
  "playedAt": "2024-07-15T14:30:00.000Z",
  "createdAt": "2024-06-04T12:30:44.019Z",
  "updatedAt": "2024-06-04T13:10:05.882Z"
}
```

📁 `screenshots/matches_crud.png`

---

### Screenshot 24 — PUT /api/teams/:id — Update Team Wins

**Method:** `PUT`
**URL:** `http://localhost:5000/api/teams/665f3b4c9f1a2b003d7e4321`
**Body (JSON):**
```json
{
  "wins": 37,
  "region": "South Asia"
}
```

**Response (200 OK):**
```json
{
  "_id": "665f3b4c9f1a2b003d7e4321",
  "teamName": "Team Nexus",
  "region": "South Asia",
  "game": "665f2c3a8e2b4a001c8f1234",
  "foundedYear": 2021,
  "wins": 37,
  "createdAt": "2024-06-04T11:05:22.779Z",
  "updatedAt": "2024-06-05T10:44:18.553Z",
  "__v": 0
}
```

📁 `screenshots/teams_crud.png`

---

### Screenshot 25 — PUT /api/players/:id — Update Player Earnings & Role

**Method:** `PUT`
**URL:** `http://localhost:5000/api/players/665f4c5d0a2b3c004e8f5432`
**Body (JSON):**
```json
{
  "earnings": 148500,
  "role": "AWPer"
}
```

**Response (200 OK):**
```json
{
  "_id": "665f4c5d0a2b3c004e8f5432",
  "gamertag": "ShadowStrike",
  "realName": "Gurpreet Singh",
  "role": "AWPer",
  "country": "India",
  "team": "665f3b4c9f1a2b003d7e4321",
  "earnings": 148500,
  "createdAt": "2024-06-04T11:22:08.334Z",
  "updatedAt": "2024-06-05T11:02:37.210Z",
  "__v": 0
}
```

📁 `screenshots/players_crud.png`

---

### Screenshot 26 — PUT /api/tournaments/:id — Update Status to Ongoing

**Method:** `PUT`
**URL:** `http://localhost:5000/api/tournaments/665f5e6e1b3c4d005f9g6543`
**Body (JSON):**
```json
{
  "status": "ongoing",
  "prizePool": 600000
}
```

**Response (200 OK):**
```json
{
  "_id": "665f5e6e1b3c4d005f9g6543",
  "name": "GameVault Open Championship 2024",
  "game": "665f2c3a8e2b4a001c8f1234",
  "prizePool": 600000,
  "format": "Double Elimination",
  "status": "ongoing",
  "startDate": "2024-07-15T00:00:00.000Z",
  "endDate": "2024-07-21T00:00:00.000Z",
  "participants": [
    "665f3b4c9f1a2b003d7e4321",
    "665f3b4c9f1a2b003d7e8888",
    "665f3b4c9f1a2b003d7e9999"
  ],
  "createdAt": "2024-06-04T11:40:55.201Z",
  "updatedAt": "2024-07-15T09:00:00.000Z",
  "__v": 3
}
```

📁 `screenshots/tournaments_crud.png`

---

### Screenshot 27 — DELETE /api/games/:id — Delete a Game

**Method:** `DELETE`
**URL:** `http://localhost:5000/api/games/665f2c3a8e2b4a001c8f9012`

**Response (200 OK):**
```json
{
  "message": "Game deleted successfully"
}
```

📁 `screenshots/games_crud.png`

---

### Screenshot 28 — GET /api/players?role=IGL&country=India — Multi-Filter Players

**Method:** `GET`
**URL:** `http://localhost:5000/api/players?role=IGL&country=India`

**Response (200 OK):**
```json
[
  {
    "_id": "665f4c5d0a2b3c004e8f5432",
    "gamertag": "ShadowStrike",
    "realName": "Gurpreet Singh",
    "role": "IGL",
    "country": "India",
    "team": {
      "_id": "665f3b4c9f1a2b003d7e4321",
      "teamName": "Team Nexus",
      "region": "South Asia"
    },
    "earnings": 148500
  },
  {
    "_id": "665f4c5d0a2b3c004e8f7890",
    "gamertag": "CodeBreaker",
    "realName": "Arjun Sharma",
    "role": "IGL",
    "country": "India",
    "team": {
      "_id": "665f3b4c9f1a2b003d7eAAAA",
      "teamName": "Bolt Squad",
      "region": "South Asia"
    },
    "earnings": 87200
  }
]
```

📁 `screenshots/players_crud.png`

---

### Screenshot 29 — GET /api/tournaments?status=ongoing — Filter Active Tournaments

**Method:** `GET`
**URL:** `http://localhost:5000/api/tournaments?status=ongoing`

**Response (200 OK):**
```json
[
  {
    "_id": "665f5e6e1b3c4d005f9g6543",
    "name": "GameVault Open Championship 2024",
    "game": {
      "_id": "665f2c3a8e2b4a001c8f1234",
      "name": "Counter-Strike 2"
    },
    "prizePool": 600000,
    "format": "Double Elimination",
    "status": "ongoing",
    "startDate": "2024-07-15T00:00:00.000Z",
    "endDate": "2024-07-21T00:00:00.000Z",
    "participants": ["665f3b4c9f1a2b003d7e4321", "665f3b4c9f1a2b003d7e8888", "665f3b4c9f1a2b003d7e9999"]
  },
  {
    "_id": "665f5e6e1b3c4d005f9gBBBB",
    "name": "Valorant Champions Circuit — Season 3",
    "game": {
      "_id": "665f2c3a8e2b4a001c8f5678",
      "name": "Valorant"
    },
    "prizePool": 250000,
    "format": "Round Robin",
    "status": "ongoing",
    "startDate": "2024-07-10T00:00:00.000Z",
    "endDate": "2024-07-25T00:00:00.000Z",
    "participants": ["665f3b4c9f1a2b003d7e9999", "665f3b4c9f1a2b003d7eCCCC"]
  }
]
```

📁 `screenshots/tournaments_crud.png`

---

### Screenshot 30 — GET /api/matches?stage=Finals — Filter Matches by Stage

**Method:** `GET`
**URL:** `http://localhost:5000/api/matches?stage=Finals`

**Response (200 OK):**
```json
[
  {
    "_id": "665f6f7f2c4d5e006g0hDDDD",
    "tournament": {
      "_id": "665f5e6e1b3c4d005f9g6543",
      "name": "GameVault Open Championship 2024"
    },
    "team1": { "teamName": "FrostByte Esports", "region": "Europe" },
    "team2": { "teamName": "Stealth Protocol",  "region": "Europe" },
    "winner": { "teamName": "FrostByte Esports", "region": "Europe" },
    "stage": "Finals",
    "score": "2-0",
    "playedAt": "2024-07-21T18:00:00.000Z"
  },
  {
    "_id": "665f6f7f2c4d5e006g0hEEEE",
    "tournament": {
      "_id": "665f5e6e1b3c4d005f9gBBBB",
      "name": "Valorant Champions Circuit — Season 3"
    },
    "team1": { "teamName": "Apex Wolves",    "region": "North America" },
    "team2": { "teamName": "Stealth Protocol","region": "Europe" },
    "winner": { "teamName": "Apex Wolves",   "region": "North America" },
    "stage": "Finals",
    "score": "13-7",
    "playedAt": "2024-07-25T20:00:00.000Z"
  }
]
```

📁 `screenshots/matches_crud.png`

---

### Screenshot 31 — Error Handling — Duplicate Gamertag (11000 Duplicate Key)

**Method:** `POST`
**URL:** `http://localhost:5000/api/players`
**Body (JSON):**
```json
{
  "gamertag": "ShadowStrike",
  "realName": "Someone Else",
  "role": "Rifler",
  "country": "Pakistan",
  "earnings": 5000
}
```

**Response (400 Bad Request):**
```json
{
  "message": "Duplicate value entered for gamertag field"
}
```

📁 `screenshots/error_handling.png`

---

### Screenshot 32 — Error Handling — Invalid ObjectId (CastError)

**Method:** `GET`
**URL:** `http://localhost:5000/api/teams/not-a-valid-id`

**Response (400 Bad Request):**
```json
{
  "message": "Invalid ID format"
}
```

📁 `screenshots/error_handling.png`

---

### Screenshot 33 — Error Handling — Team Already Registered in Tournament

**Method:** `POST`
**URL:** `http://localhost:5000/api/tournaments/665f5e6e1b3c4d005f9g6543/register`
**Body (JSON):**
```json
{
  "teamId": "665f3b4c9f1a2b003d7e4321"
}
```

**Response (400 Bad Request):**
```json
{
  "message": "Team already registered"
}
```

📁 `screenshots/tournaments_crud.png`

---

## Add-On Features (v2.0)

### 🏆 Leaderboard System

Three new leaderboard endpoints provide competitive rankings across the platform.

**Top Teams** — `GET /api/leaderboard/teams?limit=N`

Returns all teams sorted by total wins descending. Supports an optional `limit` query parameter (default 10). Each entry includes a computed rank, team name, region, associated game details, total wins, and founding year. Useful for displaying a ranked table on a dashboard or frontend.

**Top Earners** — `GET /api/leaderboard/players?limit=N`

Returns all players sorted by career earnings descending. Supports an optional `limit` query parameter (default 10). Each entry includes rank, gamertag, real name, role, country, team details, and a formatted earnings string.

**Team of the Season** — `GET /api/leaderboard/team-of-the-season`

Returns the single team with the highest win count, along with its full player roster populated from the Players collection. This is the headline feature — ideal for a "hall of fame" or featured section.

---

### 📊 Stats & Analytics

**System Overview** — `GET /api/stats/overview`

A single aggregated endpoint that returns counts for every entity in the database (games, teams, players, matches, tournaments by status), plus financial totals: total prize pool across all tournaments and total earnings paid to players. Achieved using `Promise.all` with parallel MongoDB queries for performance.

**Games Breakdown** — `GET /api/stats/games-breakdown`

Uses MongoDB's `$lookup` and `$group` aggregation pipeline to join Teams with Games and return per-game statistics: how many teams compete in each title and the combined wins across all those teams. Sorted by team count descending.

---

### 🔍 Query Filtering (Existing, Documented)

Several existing endpoints support query-string filters out of the box:

| Endpoint | Filter Params | Example |
|---|---|---|
| GET /api/teams | `region`, `game` | `?region=Europe` |
| GET /api/players | `team`, `country`, `role` | `?role=IGL&country=India` |
| GET /api/tournaments | `status`, `game` | `?status=ongoing` |
| GET /api/matches | `tournament`, `stage` | `?stage=Finals` |
| GET /api/leaderboard/teams | `limit` | `?limit=5` |
| GET /api/leaderboard/players | `limit` | `?limit=5` |

---

## Data Models

### Game
```json
{
  "name":      "string (required, unique)",
  "genre":     "string (required)",
  "platform":  "string (required)",
  "publisher": "string"
}
```

### Team
```json
{
  "teamName":    "string (required)",
  "region":      "string (required)",
  "game":        "ObjectId → Game (required)",
  "foundedYear": "number",
  "wins":        "number (default: 0)"
}
```

### Player
```json
{
  "gamertag": "string (required, unique)",
  "realName": "string (required)",
  "role":     "enum: IGL | Rifler | AWPer | Support | Entry",
  "country":  "string",
  "team":     "ObjectId → Team",
  "earnings": "number (default: 0)"
}
```

### Tournament
```json
{
  "name":         "string (required)",
  "game":         "ObjectId → Game (required)",
  "prizePool":    "number (required)",
  "format":       "enum: Single Elimination | Double Elimination | Round Robin",
  "status":       "enum: upcoming | ongoing | completed (default: upcoming)",
  "startDate":    "Date",
  "endDate":      "Date",
  "participants": "[ObjectId → Team]"
}
```

### Match
```json
{
  "tournament": "ObjectId → Tournament (required)",
  "team1":      "ObjectId → Team (required)",
  "team2":      "ObjectId → Team (required)",
  "winner":     "ObjectId → Team",
  "stage":      "string",
  "score":      "string",
  "playedAt":   "Date (default: now)"
}
```

---

## Author

Gurpreet Singh — 24BCT0292
