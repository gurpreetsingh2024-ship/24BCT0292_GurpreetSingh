const express = require('express');
const router = express.Router();
const {
  getTopTeams,
  getTopEarners,
  getTeamOfTheSeason,
} = require('../controllers/leaderboardController');

router.get('/teams', getTopTeams);
router.get('/players', getTopEarners);
router.get('/team-of-the-season', getTeamOfTheSeason);

module.exports = router;
