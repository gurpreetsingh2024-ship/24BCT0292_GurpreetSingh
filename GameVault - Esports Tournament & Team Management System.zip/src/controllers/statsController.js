const Game = require('../models/Game');
const Team = require('../models/Team');
const Player = require('../models/Player');
const Tournament = require('../models/Tournament');
const Match = require('../models/Match');

// GET /api/stats/overview
exports.getOverview = async (req, res) => {
  try {
    const [
      totalGames,
      totalTeams,
      totalPlayers,
      totalTournaments,
      totalMatches,
      upcomingCount,
      ongoingCount,
      completedCount,
      prizePoolAgg,
      earningsAgg,
    ] = await Promise.all([
      Game.countDocuments(),
      Team.countDocuments(),
      Player.countDocuments(),
      Tournament.countDocuments(),
      Match.countDocuments(),
      Tournament.countDocuments({ status: 'upcoming' }),
      Tournament.countDocuments({ status: 'ongoing' }),
      Tournament.countDocuments({ status: 'completed' }),
      Tournament.aggregate([{ $group: { _id: null, total: { $sum: '$prizePool' } } }]),
      Player.aggregate([{ $group: { _id: null, total: { $sum: '$earnings' } } }]),
    ]);

    res.status(200).json({
      title: 'GameVault — System Statistics',
      overview: {
        games: totalGames,
        teams: totalTeams,
        players: totalPlayers,
        matches: totalMatches,
        tournaments: {
          total: totalTournaments,
          upcoming: upcomingCount,
          ongoing: ongoingCount,
          completed: completedCount,
        },
        financials: {
          totalPrizePool: `$${(prizePoolAgg[0]?.total || 0).toLocaleString()}`,
          totalEarningsPaid: `$${(earningsAgg[0]?.total || 0).toLocaleString()}`,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/stats/games-breakdown
exports.getGamesBreakdown = async (req, res) => {
  try {
    const breakdown = await Team.aggregate([
      {
        $lookup: {
          from: 'games',
          localField: 'game',
          foreignField: '_id',
          as: 'gameInfo',
        },
      },
      { $unwind: '$gameInfo' },
      {
        $group: {
          _id: '$gameInfo.name',
          genre: { $first: '$gameInfo.genre' },
          teamCount: { $sum: 1 },
          totalWins: { $sum: '$wins' },
        },
      },
      { $sort: { teamCount: -1 } },
      {
        $project: {
          _id: 0,
          game: '$_id',
          genre: 1,
          teamCount: 1,
          totalWins: 1,
        },
      },
    ]);

    res.status(200).json({
      title: 'Teams & Wins by Game',
      count: breakdown.length,
      breakdown,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
