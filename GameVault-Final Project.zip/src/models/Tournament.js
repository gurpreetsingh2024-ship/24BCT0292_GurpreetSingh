const mongoose = require('mongoose');

const tournamentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  game: { type: mongoose.Schema.Types.ObjectId, ref: 'Game', required: true },
  prizePool: { type: Number, required: true },
  format: { type: String, enum: ['Single Elimination', 'Double Elimination', 'Round Robin'] },
  status: { type: String, enum: ['upcoming', 'ongoing', 'completed'], default: 'upcoming' },
  startDate: { type: Date },
  endDate: { type: Date },
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Team' }],
}, { timestamps: true });

module.exports = mongoose.model('Tournament', tournamentSchema);
